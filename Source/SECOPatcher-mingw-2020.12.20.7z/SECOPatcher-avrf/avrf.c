#include "pch.h"
#include "avrf.h"
#include "hooks.h"


#define DEFINE_HOOK(dll, name) { \
  RTL_CONSTANT_STRING(L ## #dll), \
  RTL_CONSTANT_STRING(#name), \
  NULL, \
  (PVOID)&name ## _Hook}

hook_entry s_hooks[] = {
    DEFINE_HOOK(rpcrt4.dll, RpcStringBindingComposeW),
    DEFINE_HOOK(rpcrt4.dll, RpcBindingFromStringBindingW),
    DEFINE_HOOK(rpcrt4.dll, RpcStringFreeW),
    DEFINE_HOOK(rpcrt4.dll, RpcBindingFree),
    DEFINE_HOOK(rpcrt4.dll, RpcAsyncInitializeHandle),
    DEFINE_HOOK(rpcrt4.dll, RpcAsyncCompleteCall),
    DEFINE_HOOK(rpcrt4.dll, NdrAsyncClientCall),
    DEFINE_HOOK(rpcrt4.dll, NdrClientCall2),
#ifdef _WIN64
    DEFINE_HOOK(rpcrt4.dll, Ndr64AsyncClientCall),
    DEFINE_HOOK(rpcrt4.dll, NdrClientCall3),
#endif
};

static UNICODE_STRING const s_target_images[] = {
    RTL_CONSTANT_STRING(L"osppobjs"),
    RTL_CONSTANT_STRING(L"sppobjs"),
    RTL_CONSTANT_STRING(L"SppExtComObj")
};

static VOID NTAPI DllLoadCallback(PWSTR DllName, PVOID DllBase, SIZE_T DllSize, PVOID Reserved);

static RTL_VERIFIER_DLL_DESCRIPTOR s_dll_descriptors[] = {{}};

static RTL_VERIFIER_PROVIDER_DESCRIPTOR s_provider_descriptor = {
    sizeof(RTL_VERIFIER_PROVIDER_DESCRIPTOR),
    s_dll_descriptors,
    &DllLoadCallback,
    NULL, NULL, 0, 0, NULL, NULL, NULL, NULL
};

BOOL WINAPI DllMainCRTStartup(
    PVOID dll_handle,
    DWORD reason,
    PRTL_VERIFIER_PROVIDER_DESCRIPTOR* provider
)
{
  switch (reason)
  {
    case DLL_PROCESS_ATTACH:
      DebugPrint("Attached to process\n");
      LdrDisableThreadCalloutsForDll(dll_handle);
      break;
    case DLL_PROCESS_VERIFIER:
      DebugPrint("Setting verifier provider\n");

      *provider = &s_provider_descriptor;
      break;
    default:
      break;
  }
  return TRUE;
}

static void apply_iat_hooks_on_dll(PVOID dll)
{
  UCHAR * const base = (PUCHAR)(dll);

  IMAGE_DOS_HEADER * const dosh = (PIMAGE_DOS_HEADER)(dll);
  if (dosh->e_magic != IMAGE_DOS_SIGNATURE)
    return;

  const PIMAGE_NT_HEADERS nth = (PIMAGE_NT_HEADERS)(base + dosh->e_lfanew);
  if (nth->Signature != IMAGE_NT_SIGNATURE)
    return;

  const IMAGE_DATA_DIRECTORY *import_dir =
      &nth->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];

  if (import_dir->VirtualAddress == 0 || import_dir->Size == 0)
    return;

  IMAGE_IMPORT_DESCRIPTOR * const import_begin =
      (PIMAGE_IMPORT_DESCRIPTOR)(base + import_dir->VirtualAddress);
  IMAGE_IMPORT_DESCRIPTOR * const import_end =
      (PIMAGE_IMPORT_DESCRIPTOR)((PUCHAR)(import_begin) + import_dir->Size);

  for(PIMAGE_IMPORT_DESCRIPTOR desc = import_begin; desc < import_end; ++desc)
  {
    if (!desc->Name)
      break;

    IMAGE_THUNK_DATA * const thunk_begin =
        (PIMAGE_THUNK_DATA)(base + desc->FirstThunk);
    IMAGE_THUNK_DATA * const original_thunk_begin =
        (PIMAGE_THUNK_DATA)(base + desc->OriginalFirstThunk);

    for (PIMAGE_THUNK_DATA thunk = thunk_begin, original_thunk = original_thunk_begin;
         thunk->u1.Function; ++thunk, ++original_thunk) {
      for (unsigned i = 0; i < _countof(s_hooks); ++i) {
        hook_entry *hook = s_hooks + i;
        CHAR * const import_name = ((PIMAGE_IMPORT_BY_NAME)(base + original_thunk->u1.AddressOfData))->Name;
        if (hook->old_address
            ? (hook->old_address == (PVOID)(thunk->u1.Function))
            : (!(original_thunk->u1.Ordinal & IMAGE_ORDINAL_FLAG)
               && 0 == strcmp(import_name, hook->function_name.Buffer)))
        {
          PVOID target = &thunk->u1.Function;
          SIZE_T target_size = sizeof(PVOID);
          ULONG old_protect;
          NtProtectVirtualMemory(NtCurrentProcess(), &target, &target_size, PAGE_EXECUTE_READWRITE, &old_protect);
          hook->old_address = (PVOID)(thunk->u1.Function);
          thunk->u1.Function = (ULONG_PTR)(hook->new_address);
          NtProtectVirtualMemory(NtCurrentProcess(), &target, &target_size, old_protect, &old_protect);
        }
      }
    }
  }
}

static VOID NTAPI DllLoadCallback(PWSTR DllName, PVOID DllBase, SIZE_T DllSize, PVOID Reserved)
{
  UNREFERENCED_PARAMETER(DllSize);
  UNREFERENCED_PARAMETER(Reserved);
  for (unsigned i = 0; i < _countof(s_target_images); ++i) {
    const UNICODE_STRING * target = s_target_images + i;
    if (0 == _wcsnicmp(DllName, target->Buffer, target->Length / sizeof(wchar_t)))
      apply_iat_hooks_on_dll(DllBase);
  }
}

const wchar_t* get_process_name()
{
  return s_provider_descriptor.VerifierImage;
}

void* get_function_address(const wchar_t* dll, const char* fn)
{
  UNICODE_STRING dllu;
  RtlInitUnicodeString(&dllu, dll);

  PVOID handle;
  NTSTATUS status = LdrGetDllHandle(NULL, NULL, &dllu, &handle);

  if (!NT_SUCCESS(status))
    status = LdrLoadDll(NULL, NULL, &dllu, &handle);

  if (!NT_SUCCESS(status))
    return NULL;

  ANSI_STRING fna;
  RtlInitAnsiString(&fna, fn);

  PVOID proc;
  status = LdrGetProcedureAddress(handle, &fna, 0, &proc);

  return NT_SUCCESS(status) ? proc : NULL;
}

static void* AdvApi_Table[_AdvApi_Size] = {0};

void * AdvApiGetFunc(unsigned index, char * name) {
  if (AdvApi_Table[index] != NULL) {
    return AdvApi_Table[index];
  }
  return AdvApi_Table[index] = get_function_address(L"ADVAPI32.DLL", name);
}

