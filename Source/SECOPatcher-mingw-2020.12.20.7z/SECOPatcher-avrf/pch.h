#pragma once

#ifndef _NO_CRT_STDIO_INLINE
#define _NO_CRT_STDIO_INLINE 1
#endif

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <ntstatus.h>
#ifndef WIN32_NO_STATUS
#define WIN32_NO_STATUS
#endif
#include <windows.h>
#include <winternl.h>
#include <winnt.h>
#include <rpc.h>
#include <wincrypt.h>

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "nt_defs.h"

#ifdef _DEBUG
#	define DebugPrint(str, ...) DbgPrintEx(-1, 0, "[SppExtComObjHookAvrf] " str, ##__VA_ARGS__)
#else
#	define DebugPrint(str, ...)
#endif
