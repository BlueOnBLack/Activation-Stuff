#!/bin/bash
MACHINE="$(gcc -dumpmachine)"
mkdir -p "build_${MACHINE}"
cd "build_${MACHINE}"
for i in $(find .. -maxdepth 1 -type d | cut -f2 -d'/' | grep 'SECO'); do
echo Building ${i} for ${MACHINE}...
mkdir -p "${i}"
cd "${i}"
cmake -GNinja "../../${i}"
ninja
cd ..
done
cd ..