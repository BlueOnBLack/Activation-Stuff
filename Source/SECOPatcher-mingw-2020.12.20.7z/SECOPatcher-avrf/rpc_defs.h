//
// Created by Administrator on 2019/4/6.
//
#pragma once

#ifndef AVRF_RPC_DEFS_H
#define AVRF_RPC_DEFS_H

#include "pch.h"

typedef struct hook_entry
{
  UNICODE_STRING dll_name;
  ANSI_STRING function_name;
  PVOID old_address;
  PVOID new_address;
} hook_entry;

extern hook_entry s_hooks[];

#define index_suffix(name) name ## _Index

typedef enum _APIIndex {
  index_suffix(RpcStringBindingComposeW) = 0,
  index_suffix(RpcBindingFromStringBindingW),
  index_suffix(RpcStringFreeW),
  index_suffix(RpcBindingFree),
  index_suffix(RpcAsyncInitializeHandle),
  index_suffix(RpcAsyncCompleteCall),
  index_suffix(NdrAsyncClientCall),
  index_suffix(NdrClientCall2),
#ifdef _WIN64
  index_suffix(Ndr64AsyncClientCall),
  index_suffix(NdrClientCall3)
#endif
} APIIndex;

#undef index_suffix

// Function typedef
typedef HMODULE (WINAPI *pfnLoadLibraryW)(LPCWSTR lpFileName);
typedef RPC_STATUS (RPC_ENTRY *pfnRpcStringBindingComposeW)(WCHAR *ObjUuid, WCHAR *ProtSeq, WCHAR *NetworkAddr, WCHAR *EndPoint, WCHAR *Options, WCHAR **StringBinding);
typedef RPC_STATUS (RPC_ENTRY *pfnRpcBindingFromStringBindingW)(WCHAR *StringBinding, RPC_BINDING_HANDLE *Binding);
typedef RPC_STATUS (RPC_ENTRY *pfnRpcStringFreeW)(WCHAR **String);
typedef RPC_STATUS (RPC_ENTRY *pfnRpcBindingFree)(RPC_BINDING_HANDLE *Binding);
typedef RPC_STATUS (RPC_ENTRY *pfnRpcAsyncInitializeHandle)(PRPC_ASYNC_STATE pAsync, unsigned int Size);
typedef RPC_STATUS (RPC_ENTRY *pfnRpcAsyncCompleteCall)(PRPC_ASYNC_STATE pAsync, PVOID Reply);
typedef CLIENT_CALL_RETURN (RPC_VAR_ENTRY *pfnNdrAsyncClientCall)(PMIDL_STUB_DESC pStubDescriptor, PFORMAT_STRING pFormat, ...);
typedef CLIENT_CALL_RETURN (RPC_VAR_ENTRY *pfnNdrClientCall2)(PMIDL_STUB_DESC pStubDescriptor, PFORMAT_STRING pFormat, ...);
#ifdef _WIN64
typedef CLIENT_CALL_RETURN (RPC_VAR_ENTRY *pfnNdr64AsyncClientCall)(MIDL_STUBLESS_PROXY_INFO *pProxyInfo, unsigned long nProcNum, void *pReturnValue, ...);
typedef CLIENT_CALL_RETURN (RPC_VAR_ENTRY *pfnNdrClientCall3)(MIDL_STUBLESS_PROXY_INFO *pProxyInfo, unsigned long nProcNum, void *pReturnValue, ...);
#endif

#define GET_ORIGINAL_FUNC(name) (*(pfn##name)(s_hooks[name ## _Index].old_address))
#define CALL_ORIGINAL_FUNC(name, ...) (GET_ORIGINAL_FUNC(name)(__VA_ARGS__))

#endif //AVRF_RPC_DEFS_H
