#pragma once

#include "rpc_defs.h"
#include "advapi32_defs.h"
#ifdef __cplusplus
extern "C" {
#endif

const wchar_t* get_process_name();

void* get_function_address(const wchar_t* dll, const char* fn);

#ifdef __cplusplus
};
#endif
