# HWIDGEN-mk6

## Windows 10 Digital License Generation & KMS38 activation tool

### General Description

This tool is used to generate a valid and genuine Digital License obtained directly from Microsoft Retail Activation Servers, which can be used to activate Windows 10.
The program also includes a method for server variants of Windows 10, and also LTSC/LTSB variants.

#### Compile with AUTOHOTKEY ! All the files must be at the same directory as the original script, otherwise the compiler won't be able to find them!

### Supported Variants (HWIDGEN)

• **Windows 10 Home**
• **Windows 10 Home N**
• **Windows 10 Home Single Language**
• **Windows 10 Home Single Language N**
• **Windows 10 Professional**
• **Windows 10 Professional N**
• **Windows 10 Professional S**
• **Windows 10 Education**
• **Windows 10 Education N**
• **Wimdows 10 Education S**
• **Windows 10 Enterprise**
• **Windows 10 Enterprise N**
• **Windows 10 Enterprise S**
• **Windows 10 (any) LTSB**

### Supported Variants (KMS38)

• **All editions of Windows Server 2016>**
• **Windows 10 (any) LTSC**

### THIS PROGRAM DOES NOT SUPPORT ANY OFFICE PRODUCTS!

Credit goes to **s1ave77** for creating the tool. He never wanted it to be open source but since he acted like a douchebag and left the community I'm not going to obey his will. Sorry man, you earned it ; )




