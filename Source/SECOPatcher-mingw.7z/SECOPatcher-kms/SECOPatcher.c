#include "targetver.h"
#include <windows.h>
#include <tlhelp32.h>
#include <string.h>
#include <stdio.h>

#ifdef _MSC_VER
#pragma warning(push)
// C4091: 'typedef ': ignored on left of '' when no variable is declared
#pragma warning(disable:4091)
#endif

#include <imagehlp.h>

#ifdef _MSC_VER
#pragma warning(pop)
#endif

#include "defines.h"
#include "crypto.h"
#include "kms.h"

#ifdef __cplusplus
#define DLL_EXPORT extern "C" __declspec(dllexport)
#else
#define DLL_EXPORT __declspec(dllexport)
#endif

// Function prototype
BOOL WINAPI PatchIAT(HMODULE hModule);

// Original function pointers
#define DEFINE_HOOK(module, name) { module, #name, name##_Hook, NULL }
#define GET_ORIGINAL_STORE(name) (&APIHooks[name##_Index].original)
#define CALL_ORIGINAL_FUNC(name, ...) (*(pfn##name)(APIHooks[name##_Index].original))(__VA_ARGS__)

typedef enum _APIIndex {
    LoadLibraryW_Index = 0,
    RpcStringBindingComposeW_Index,
    RpcBindingFromStringBindingW_Index,
    RpcStringFreeW_Index,
    RpcBindingFree_Index,
    RpcAsyncInitializeHandle_Index,
    RpcAsyncCompleteCall_Index,
    NdrAsyncClientCall_Index,
    NdrClientCall2_Index,
#ifdef _WIN64
    Ndr64AsyncClientCall_Index,
    NdrClientCall3_Index
#endif
} APIIndex;

static APIHook APIHooks[] =
{
    DEFINE_HOOK("kernel32.dll", LoadLibraryW),
    DEFINE_HOOK("rpcrt4.dll", RpcStringBindingComposeW),
    DEFINE_HOOK("rpcrt4.dll", RpcBindingFromStringBindingW),
    DEFINE_HOOK("rpcrt4.dll", RpcStringFreeW),
    DEFINE_HOOK("rpcrt4.dll", RpcBindingFree),
    DEFINE_HOOK("rpcrt4.dll", RpcAsyncInitializeHandle),
    DEFINE_HOOK("rpcrt4.dll", RpcAsyncCompleteCall),
    DEFINE_HOOK("rpcrt4.dll", NdrAsyncClientCall),
    DEFINE_HOOK("rpcrt4.dll", NdrClientCall2),
#ifdef _WIN64
    DEFINE_HOOK("rpcrt4.dll", Ndr64AsyncClientCall),
    DEFINE_HOOK("rpcrt4.dll", NdrClientCall3),
#endif
};

extern KMSServerSettings Settings;

RpcConnection newRpcConnection = {FALSE};

HMODULE WINAPI LoadLibraryW_Hook(LPCWSTR lpFileName)
{
    HMODULE hModule = CALL_ORIGINAL_FUNC(LoadLibraryW, lpFileName);

    if ( hModule == NULL )
    {
        SetLastError(GetLastError());
        return NULL;
    }

    OutputDebugStringEx(L"[SppExtComObjHook] LoadLibraryW called. [lpFileName: %s, base: 0x%p]\n", lpFileName, hModule);

    LPCWSTR fileName = wcsrchr(lpFileName, L'\\');
    if (fileName == NULL) {
        fileName = lpFileName;
    } else {
        ++fileName;
    }

    if ( !_wcsicmp(fileName, L"OSPPOBJS.DLL") && !_wcsicmp(fileName, L"SPPOBJS.DLL") )
    {
        OutputDebugStringEx(L"[SppExtComObjHook] Not a target module. Skipped patching...\n");
        return hModule;
    }

    PatchIAT(hModule);

    return hModule;
}

RPC_STATUS RPC_ENTRY RpcStringBindingComposeW_Hook(WCHAR *ObjUuid, WCHAR *ProtSeq, WCHAR *NetworkAddr, WCHAR *EndPoint, WCHAR *Options, WCHAR **StringBinding)
{
    OutputDebugStringEx(L"[SppExtComObjHook] RpcStringBindingComposeW called [ProtSeq: %s, NetWorkAddr: %s, EndPoint: %s].\n", ProtSeq, NetworkAddr, EndPoint);

    // Check destination address and hook
    if ( ProtSeq != NULL && _wcsicmp(ProtSeq, PROTO_SEQ_TCP) == 0 )
    {
        ReadRegistrySettings();

        if ( !newRpcConnection.Initialized )
        {
            if ( Settings.KMSEnabled )
            {
                OutputDebugStringEx(L"[SppExtComObjHook] Connection Detected... Emulating Server...\n");

                newRpcConnection.Initialized = TRUE;
                newRpcConnection.hThread = GetCurrentThread();
                swprintf_s(newRpcConnection.pszStringBinding, _countof(newRpcConnection.pszStringBinding), L"%s:%s[%s]", ProtSeq, NetworkAddr, EndPoint);
                *StringBinding = newRpcConnection.pszStringBinding;

                return RPC_S_OK;
            }
            else
            {
                // Redirect rpcrt4 call to localhost
                OutputDebugStringEx(L"[SppExtComObjHook] Replaced NetworkAddr from %s to %s\n", NetworkAddr, LOCALHOST_IP);

                newRpcConnection.Initialized = FALSE;

                NetworkAddr = LOCALHOST_IP;
            }
        }
    }

    // Call original function
    return CALL_ORIGINAL_FUNC(RpcStringBindingComposeW, ObjUuid, ProtSeq, NetworkAddr, EndPoint, Options, StringBinding);
}

RPC_STATUS RPC_ENTRY RpcBindingFromStringBindingW_Hook(WCHAR *StringBinding, RPC_BINDING_HANDLE *Binding)
{
    if ( StringBinding != NULL && Binding != NULL )
    {
        if ( newRpcConnection.Initialized && newRpcConnection.pAsync == NULL )
        {
            if ( newRpcConnection.hThread == GetCurrentThread() && !_wcsicmp(StringBinding, newRpcConnection.pszStringBinding) )
            {
                OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Return fake binding...\n");

                GetRandomBytes((BYTE *)&newRpcConnection.hRpcBinding, sizeof(newRpcConnection.hRpcBinding));
                *Binding = newRpcConnection.hRpcBinding;

                OutputDebugStringEx(L"[SppExtComObjHook] RpcBindingFromStringBindingW called [StringBinding: %s, Binding: 0x%p @ 0x%p].\n", StringBinding, *Binding, Binding);

                return RPC_S_OK;
            }
        }
    }

    RPC_STATUS ret = CALL_ORIGINAL_FUNC(RpcBindingFromStringBindingW, StringBinding, Binding);

    OutputDebugStringEx(L"[SppExtComObjHook] RpcBindingFromStringBindingW called [StringBinding: %s, Binding: 0x%p @ 0x%p].\n", StringBinding, *Binding, Binding);

    return ret;
}

RPC_STATUS RPC_ENTRY RpcStringFreeW_Hook(WCHAR **String)
{
    if ( newRpcConnection.Initialized && String != NULL )
    {
        if ( newRpcConnection.hThread == GetCurrentThread() && !_wcsicmp(*String, newRpcConnection.pszStringBinding) )
        {
            OutputDebugStringEx(L"[SppExtComObjHook] Free StringBinding...\n");

            memset(newRpcConnection.pszStringBinding, 0, sizeof(newRpcConnection.pszStringBinding));
            *String = NULL;

            return RPC_S_OK;
        }
    }

    return CALL_ORIGINAL_FUNC(RpcStringFreeW, String);
}

RPC_STATUS RPC_ENTRY RpcBindingFree_Hook(RPC_BINDING_HANDLE *Binding)
{
    if ( newRpcConnection.Initialized && Binding != NULL )
    {
        if ( *Binding == newRpcConnection.hRpcBinding && newRpcConnection.hThread == GetCurrentThread() )
        {
            OutputDebugStringEx(L"[SppExtComObjHook] Free Connection...\n");

            newRpcConnection.Initialized = FALSE;
            newRpcConnection.hRpcBinding = NULL;
            newRpcConnection.pAsync = NULL;
            newRpcConnection.hThread = NULL;

            return RPC_S_OK;
        }
    }

    return CALL_ORIGINAL_FUNC(RpcBindingFree, Binding);
}

RPC_STATUS RPC_ENTRY RpcAsyncInitializeHandle_Hook(PRPC_ASYNC_STATE pAsync, unsigned int Size)
{
    RPC_STATUS status = CALL_ORIGINAL_FUNC(RpcAsyncInitializeHandle, pAsync, Size);

    if ( status != RPC_S_OK )
        return status;

    if ( newRpcConnection.Initialized && newRpcConnection.hRpcBinding != NULL && newRpcConnection.pAsync == NULL )
    {
        if ( newRpcConnection.hThread == GetCurrentThread() )
        {
            OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Saved Async Handle\n");
            newRpcConnection.pAsync = pAsync;
        }
    }

    return status;
}

RPC_STATUS RPC_ENTRY RpcAsyncCompleteCall_Hook(PRPC_ASYNC_STATE pAsync, PVOID Reply)
{
    if ( pAsync != NULL && Reply != NULL )
    {
        if ( newRpcConnection.Initialized && newRpcConnection.pAsync != NULL && newRpcConnection.hRpcBinding != NULL )
        {
            if ( newRpcConnection.hThread == GetCurrentThread() && pAsync == newRpcConnection.pAsync )
            {
                OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Return RPC_S_OK...\n");

                return RPC_S_OK;
            }
        }
    }

    return CALL_ORIGINAL_FUNC(RpcAsyncCompleteCall, pAsync, Reply);
}

CLIENT_CALL_RETURN RPC_VAR_ENTRY NdrAsyncClientCall_Hook(PMIDL_STUB_DESC pStubDescriptor, PFORMAT_STRING pFormat, ...)
{
    OutputDebugStringEx(L"[SppExtComObjHook] NdrAsyncClientCall called\n");

#ifdef _WIN64
    va_list ap = NULL;
    va_start(ap, pFormat);
    PRPC_ASYNC_STATE pAsync = (PRPC_ASYNC_STATE)va_arg(ap, PVOID);
    RPC_BINDING_HANDLE Binding = (RPC_BINDING_HANDLE)va_arg(ap, PVOID);
    int requestSize = (int)va_arg(ap, int);
    BYTE *requestData = (BYTE *)va_arg(ap, PVOID);
    int *responseSize = (int *)va_arg(ap, PVOID);
    BYTE **responseData = (BYTE **)va_arg(ap, PVOID);
    va_end(ap);
#else
    DWORD* funcVarList = *(DWORD**)(((BYTE*)&pFormat) + sizeof(const unsigned char*));
    PRPC_ASYNC_STATE pAsync = (PRPC_ASYNC_STATE)(funcVarList[0]);
    RPC_BINDING_HANDLE Binding = (RPC_BINDING_HANDLE)(funcVarList[1]);
    int requestSize = (int)(funcVarList[2]);
    BYTE* requestData = (BYTE*)(funcVarList[3]);
    int* responseSize = (int*)(funcVarList[4]);
    BYTE** responseData = (BYTE**)(funcVarList[5]);
#endif

    OutputDebugStringEx(L"[SppExtComObjHook] pStubDescriptor = 0x%p, pFormat = 0x%p, pAsync = 0x%p, Binding = 0x%p, requestSize = %d, resuestData = 0x%p, responseSize = 0x%p, responseData = 0x%p\n",
        pStubDescriptor, pFormat, pAsync, Binding, requestSize, requestData, responseSize, responseData);

    if ( newRpcConnection.Initialized && pStubDescriptor != NULL && pFormat != NULL )
    {
        if ( newRpcConnection.hRpcBinding == Binding && newRpcConnection.pAsync == pAsync )
        {
            if ( newRpcConnection.hThread == GetCurrentThread() )
            {
                if ( pAsync->u.APC.NotificationRoutine != NULL && pAsync->u.APC.NotificationRoutine != INVALID_HANDLE_VALUE )
                {
                    ReadRegistrySettings();

                    OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Writing Response!\n");

                    if ( ActivationResponse(requestSize, requestData, responseSize, responseData) == RPC_S_OK )
                    {
                        OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Activation Success!\n");
                    }
                    else
                    {
                        OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Activation Failed!\n");
                    }

                    SetEvent(pAsync->u.APC.NotificationRoutine);

                    CLIENT_CALL_RETURN ret = { 0 };

                    return ret;
                }
            }
        }
    }

#ifdef _WIN64
    return CALL_ORIGINAL_FUNC(NdrAsyncClientCall, pStubDescriptor, pFormat, pAsync, Binding, requestSize, requestData, responseSize, responseData);
#else
    return CALL_ORIGINAL_FUNC(NdrAsyncClientCall, pStubDescriptor, pFormat, funcVarList);
#endif
}

CLIENT_CALL_RETURN RPC_VAR_ENTRY NdrClientCall2_Hook(PMIDL_STUB_DESC pStubDescriptor, PFORMAT_STRING pFormat, ...)
{
    OutputDebugStringEx(L"[SppExtComObjHook] NdrClientCall2 called\n");

#ifdef _WIN64
    va_list ap = NULL;
    va_start(ap, pFormat);
    RPC_BINDING_HANDLE Binding = (RPC_BINDING_HANDLE)va_arg(ap, PVOID);
    int requestSize = (int)va_arg(ap, int);
    BYTE *requestData = (BYTE *)va_arg(ap, PVOID);
    int *responseSize = (int *)va_arg(ap, PVOID);
    BYTE **responseData = (BYTE **)va_arg(ap, PVOID);
    va_end(ap);
#else
    DWORD* funcVarList = *(DWORD**)(((BYTE*)&pFormat) + sizeof(const unsigned char*));
    RPC_BINDING_HANDLE Binding = (RPC_BINDING_HANDLE)(funcVarList[0]);
    int requestSize = (int)(funcVarList[1]);
    BYTE* requestData = (BYTE*)(funcVarList[2]);
    int* responseSize = (int*)(funcVarList[3]);
    BYTE** responseData = (BYTE**)(funcVarList[4]);
#endif

    OutputDebugStringEx(L"[SppExtComObjHook] pStubDescriptor = 0x%p, pFormat = 0x%p, Binding = 0x%p, requestSize = %d, resuestData = 0x%p, responseSize = 0x%p, responseData = 0x%p\n",
        pStubDescriptor, pFormat, Binding, requestSize, requestData, responseSize, responseData);

    if ( newRpcConnection.Initialized && pStubDescriptor != NULL && pFormat != NULL )
    {
        if ( newRpcConnection.hRpcBinding == Binding )
        {
            if ( newRpcConnection.hThread == GetCurrentThread() )
            {
                ReadRegistrySettings();

                OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Writing Response!\n");

                if ( ActivationResponse(requestSize, requestData, responseSize, responseData) == RPC_S_OK )
                {
                    OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Activation Success!\n");
                }
                else
                {
                    OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Activation Failed!\n");
                }

                CLIENT_CALL_RETURN ret = { 0 };

                return ret;
            }
        }
    }

#ifdef _WIN64
    return CALL_ORIGINAL_FUNC(NdrClientCall2, pStubDescriptor, pFormat, Binding, requestSize, requestData, responseSize, responseData);
#else
    return CALL_ORIGINAL_FUNC(NdrClientCall2, pStubDescriptor, pFormat, funcVarList);
#endif
}

#ifdef _WIN64
CLIENT_CALL_RETURN RPC_VAR_ENTRY Ndr64AsyncClientCall_Hook(MIDL_STUBLESS_PROXY_INFO *pProxyInfo, unsigned long nProcNum, void *pReturnValue, ...)
{
    OutputDebugStringEx(L"[SppExtComObjHook] Ndr64AsyncClientCall called\n");

    va_list ap = NULL;
    va_start(ap, pReturnValue);
    PRPC_ASYNC_STATE pAsync = (PRPC_ASYNC_STATE)va_arg(ap, PVOID);
    RPC_BINDING_HANDLE Binding = (RPC_BINDING_HANDLE)va_arg(ap, PVOID);
    int requestSize = va_arg(ap, int);
    BYTE *requestData = va_arg(ap, BYTE *);
    int *responseSize = va_arg(ap, int *);
    BYTE **responseData = va_arg(ap, BYTE **);
    va_end(ap);

    OutputDebugStringEx(L"[SppExtComObjHook] pProxyInfo = 0x%p, nProcNum = %u, pReturnValue = 0x%p, pAsync = 0x%p, Binding = 0x%p, requestSize = %d, resuestData = 0x%p, responseSize = 0x%p, responseData = 0x%p\n",
        pProxyInfo, nProcNum, pReturnValue, pAsync, Binding, requestSize, requestData, responseSize, responseData);

    if ( newRpcConnection.Initialized && pProxyInfo != NULL )
    {
        if ( newRpcConnection.hRpcBinding == Binding && newRpcConnection.pAsync == pAsync )
        {
            if ( newRpcConnection.hThread == GetCurrentThread() )
            {
                if ( pAsync->u.APC.NotificationRoutine != NULL && pAsync->u.APC.NotificationRoutine != INVALID_HANDLE_VALUE )
                {
                    ReadRegistrySettings();

                    OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Writing Response!\n");

                    if ( ActivationResponse(requestSize, requestData, responseSize, responseData) == RPC_S_OK )
                    {
                        OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Activation Success!\n");
                    }
                    else
                    {
                        OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Activation Failed!\n");
                    }

                    SetEvent((HANDLE)(pAsync->u.APC.NotificationRoutine));

                    CLIENT_CALL_RETURN ret = { 0 };

                    return ret;
                }
            }
        }
    }

    return CALL_ORIGINAL_FUNC(Ndr64AsyncClientCall, pProxyInfo, nProcNum, pReturnValue, pAsync, Binding, requestSize, requestData, responseSize, responseData);
}

CLIENT_CALL_RETURN RPC_VAR_ENTRY NdrClientCall3_Hook(MIDL_STUBLESS_PROXY_INFO *pProxyInfo, unsigned long nProcNum, void *pReturnValue, ...)
{
    OutputDebugStringEx(L"[SppExtComObjHook] NdrClientCall3 called\n");

    va_list ap = NULL;
    va_start(ap, pReturnValue);
    RPC_BINDING_HANDLE Binding = (RPC_BINDING_HANDLE)va_arg(ap, PVOID);
    int requestSize = va_arg(ap, int);
    BYTE *requestData = va_arg(ap, BYTE *);
    int *responseSize = va_arg(ap, int *);
    BYTE **responseData = va_arg(ap, BYTE **);
    va_end(ap);

    OutputDebugStringEx(L"[SppExtComObjHook] pProxyInfo = 0x%p, nProcNum = %u, pReturnValue = 0x%p, Binding = 0x%p, requestSize = %d, resuestData = 0x%p, responseSize = 0x%p, responseData = 0x%p\n",
        pProxyInfo, nProcNum, pReturnValue, Binding, requestSize, requestData, responseSize, responseData);

    if ( newRpcConnection.Initialized && pProxyInfo != NULL )
    {
        if ( newRpcConnection.hRpcBinding == Binding )
        {
            if ( newRpcConnection.hThread == GetCurrentThread() )
            {
                ReadRegistrySettings();

                OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Writing Response!\n");

                if ( ActivationResponse(requestSize, requestData, responseSize, responseData) == RPC_S_OK )
                {
                    OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Activation Success!\n");
                }
                else
                {
                    OutputDebugStringEx(L"[SppExtComObjHook] Emulating Server... Activation Failed!\n");
                }

                CLIENT_CALL_RETURN ret = { 0 };

                return ret;
            }
        }
    }

    return CALL_ORIGINAL_FUNC(NdrClientCall3, pProxyInfo, nProcNum, pReturnValue, Binding, requestSize, requestData, responseSize, responseData);
}
#endif

PIMAGE_IMPORT_DESCRIPTOR WINAPI GetImportDescriptor(HMODULE hModule)
{
    PIMAGE_NT_HEADERS pNtHeaders;
    PIMAGE_OPTIONAL_HEADER pOptionalHeader;
    PIMAGE_DATA_DIRECTORY pDirectory;
    ULONG_PTR Address;
    LPBYTE pb = (LPBYTE)hModule;

    if ( ((WORD *)pb)[0] != IMAGE_DOS_SIGNATURE )
        return NULL;

    PIMAGE_DOS_HEADER pDosHeader = (PIMAGE_DOS_HEADER)hModule;
    pNtHeaders = (PIMAGE_NT_HEADERS)(pb + pDosHeader->e_lfanew);

    if ( ((DWORD *)pNtHeaders)[0] != IMAGE_NT_SIGNATURE )
        return NULL;

    pOptionalHeader = &pNtHeaders->OptionalHeader;
    pDirectory = &pOptionalHeader->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    Address = pDirectory->VirtualAddress;

    if ( Address == 0 )
        return NULL;

    return (PIMAGE_IMPORT_DESCRIPTOR)((ULONG_PTR)hModule + Address);
}

// Create RpcStringBindingComposeW and GetProcAddressHook hooks
BOOL WINAPI PatchIATInternal(HMODULE hModule, APIHook* APIHookInfo)
{
    // Get original function addresses being hooked
    FARPROC Original = GetProcAddress(GetModuleHandleA(APIHookInfo->module), APIHookInfo->name);
    if ( Original == NULL )
        return FALSE;

    // Hold original address
    if (APIHookInfo->original == NULL)
        APIHookInfo->original = Original;

    // Get base address of our process primary module
    ULONG_PTR BaseAddress = (ULONG_PTR)hModule;

    // Get import table
    PIMAGE_IMPORT_DESCRIPTOR pImageImportDescriptor = GetImportDescriptor(hModule);

    if ( pImageImportDescriptor == NULL )
        return FALSE;

    // Search through import table
    for ( ; pImageImportDescriptor->Name; pImageImportDescriptor++ )
    {

        LPCSTR lpDllName = (LPCSTR)(BaseAddress + pImageImportDescriptor->Name);

        if (_stricmp(lpDllName, APIHookInfo->module))
            continue;

        PIMAGE_THUNK_DATA pImageThunkData = (PIMAGE_THUNK_DATA)(BaseAddress + pImageImportDescriptor->FirstThunk);
        PIMAGE_THUNK_DATA pOrgImageThunkData = (PIMAGE_THUNK_DATA)(BaseAddress + pImageImportDescriptor->OriginalFirstThunk);

        for ( ; pImageThunkData->u1.Function; pImageThunkData++, pOrgImageThunkData++ )
        {
            FARPROC pfnImportedFunc = (FARPROC)(pImageThunkData->u1.Function);

            // Patch
            if ( pfnImportedFunc == Original )
            {
                OutputDebugStringEx(L"[SppExtComObjHook] Replaced %S import 0x%p @ 0x%p with hook entry 0x%p in base 0x%p.\n",
                    APIHookInfo->name, (void*)pImageThunkData->u1.Function, (void*)(&pImageThunkData->u1.Function), APIHookInfo->hook, hModule);
                DWORD flOldProtect;
                VirtualProtect(pImageThunkData, sizeof(ULONG_PTR), PAGE_READWRITE, &flOldProtect);
                WriteProcessMemory(GetCurrentProcess(), pImageThunkData, &APIHookInfo->hook, sizeof(ULONG_PTR), NULL);
                VirtualProtect(pImageThunkData, sizeof(ULONG_PTR), flOldProtect, &flOldProtect);
            }
        }
    }

    return TRUE;
}

BOOL WINAPI PatchIAT(HMODULE hModule)
{
    BOOL bRet = TRUE;

    for ( unsigned i = 0; i < _countof(APIHooks); i++ )
    {
        if (!PatchIATInternal(hModule, &APIHooks[i]))
        {
            bRet = FALSE;
            break;
        }
    }

    return bRet;
}

BOOL WINAPI PauseResumeThreadList(DWORD dwOwnerPID, BOOL bResumeThread)
{
    HANDLE hThreadSnap = NULL;
    BOOL bRet = FALSE;
    THREADENTRY32 te32 = { 0 };

    // Take a snapshot of all threads currently in the system.
    hThreadSnap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (hThreadSnap == INVALID_HANDLE_VALUE)
        return FALSE;

    // Fill in the size of the structure before using it.
    te32.dwSize = sizeof(THREADENTRY32);

    // Walk the thread snapshot to find all threads of the process.
    // If the thread belongs to the process, add its information
    // to the display list.
    if (Thread32First(hThreadSnap, &te32))
    {
        do
        {
            if (te32.th32OwnerProcessID == dwOwnerPID)
            {
                HANDLE hThread = OpenThread(THREAD_SUSPEND_RESUME, FALSE, te32.th32ThreadID);

                if (bResumeThread)
                    ResumeThread(hThread);
                else
                    SuspendThread(hThread);

                CloseHandle(hThread);
            }

        } while (Thread32Next(hThreadSnap, &te32));

        bRet = TRUE;
    }

    // Do not forget to clean up the snapshot object.
    CloseHandle(hThreadSnap);

    return bRet;
}

BOOL WINAPI FindProcessIdByName(LPCWSTR lpPrimaryModuleName, DWORD *lpProcessId)
{
    HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hProcessSnap == INVALID_HANDLE_VALUE)
        return FALSE;

    PROCESSENTRY32W pe32;
    pe32.dwSize = sizeof(pe32);

    BOOL bRet = FALSE;

    if (Process32FirstW(hProcessSnap, &pe32))
    {
        do
        {
            if (pe32.szExeFile != NULL && !_wcsicmp(pe32.szExeFile, lpPrimaryModuleName))
            {
                bRet = TRUE;
                *lpProcessId = pe32.th32ProcessID;
            }

        } while (Process32NextW(hProcessSnap, &pe32));
    }

    CloseHandle(hProcessSnap);

    return bRet;
}

BOOL WINAPI InjectDll(LPCWSTR lpDllName, DWORD dwProcessId)
{
    BOOL bRet = FALSE;

    HANDLE hProcess = NULL;
    LPVOID addrDllPath = NULL;

    do
    {
        hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
        if (NULL == hProcess)
            break;

        SIZE_T allocSize = (wcslen(lpDllName) + 1) * sizeof(WCHAR);
        addrDllPath = VirtualAllocEx(hProcess, NULL, allocSize, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
        if (NULL == addrDllPath)
            break;

        if (!WriteProcessMemory(hProcess, addrDllPath, lpDllName, allocSize, NULL))
            break;

        pfnLoadLibraryW addrLoadLibraryW = (void *)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryW");
        if (addrLoadLibraryW == NULL)
            break;

        HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, (void *)addrLoadLibraryW, addrDllPath, 0, NULL);
        if (hThread == NULL)
            break;

        WaitForSingleObject(hThread, INFINITE);

        // This may be wrong on x64 because LoadLibrary returns HMODULE -> 64-bit
        DWORD dwExitCode;
        GetExitCodeThread(hThread, &dwExitCode);
        CloseHandle(hThread);

        if (dwExitCode != 0)
            bRet = TRUE;

    } while (FALSE);

    if (addrDllPath != NULL)
        VirtualFreeEx(hProcess, addrDllPath, 0, MEM_RELEASE);
    if (hProcess != NULL)
        CloseHandle(hProcess);

    return bRet;
}

DLL_EXPORT void InitHook(void) { }

BOOL WINAPI DllMainCRTStartup(
    _In_ HINSTANCE hinstDLL,
    _In_ DWORD fdwReason,
    _In_ LPVOID lpvReserved)
{
    UNREFERENCED_PARAMETER(hinstDLL);
    UNREFERENCED_PARAMETER(lpvReserved);

    OutputDebugStringEx(L"[SppExtComObjHook] DllMain entry. [nReason: %u]\n", fdwReason);

    BOOL bRet = TRUE;

    switch (fdwReason)
    {
    case DLL_PROCESS_ATTACH:
    {
        wchar_t CurrentExePath[MAX_PATH];
        GetModuleFileNameW(NULL, CurrentExePath, MAX_PATH);
        wchar_t* CurrentExeName = wcsrchr(CurrentExePath, L'\\') + 1;
        if (0 == _wcsicmp(CurrentExeName, L"rundll32.exe"))
        {

        }
        else
        {
            bRet = DisableThreadLibraryCalls(hinstDLL) && PatchIAT(GetModuleHandleA(NULL));
        }

        break;
    }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }

    return bRet;
}

void CALLBACK PatcherMain(
    HWND hWnd,
    HINSTANCE hInstance,
    LPWSTR lpCmdLine,
    int nShowCmd)
{
    UNREFERENCED_PARAMETER(hWnd);
    UNREFERENCED_PARAMETER(hInstance);
    UNREFERENCED_PARAMETER(nShowCmd);

    STARTUPINFOW si;
    PROCESS_INFORMATION pi = { 0 };
    DWORD dwRet = ERROR_SUCCESS;
    BOOL bRet;

    DWORD SppSvcPid = 0;

    if (NULL != wcsstr(lpCmdLine, L"SppExtComObj.exe") && FindProcessIdByName(L"sppsvc.exe", &SppSvcPid))
    {
        PauseResumeThreadList(SppSvcPid, FALSE);
        OutputDebugStringEx(L"[SppExtComObjPatcher] Process sppsvc.exe [pid: %u] suspended.\n", SppSvcPid);
    }

    GetStartupInfoW(&si);

    bRet = CreateProcessW(NULL, lpCmdLine, NULL, NULL, FALSE, DEBUG_PROCESS | DEBUG_ONLY_THIS_PROCESS | CREATE_SUSPENDED | DETACHED_PROCESS, NULL, NULL, &si, &pi);
    if (!bRet)
    {
        dwRet = GetLastError();
        OutputDebugStringEx(L"[SppExtComObjPatcher] CreateProcess failed [cmdLine: %s, error: 0x%08u].\n", lpCmdLine, dwRet);
        goto fail;
    }

    bRet = DebugActiveProcessStop(pi.dwProcessId);
    if (!bRet)
    {
        dwRet = GetLastError();
        OutputDebugStringEx(L"[SppExtComObjPatcher] DebugActiveProcessStop failed [error: 0x%08u].\n", dwRet);
        goto fail;
    }

    OutputDebugStringEx(L"[SppExtComObjPatcher] CreateProcess succeeded [cmdLine: %s, pid: %u, tid: %u].\n", lpCmdLine, pi.dwProcessId, pi.dwThreadId);
    Sleep(100);
    // SuspendThread(pi.hThread);
    InjectDll(DLL_NAME, pi.dwProcessId);

fail:
    ResumeThread(pi.hThread);

    if (SppSvcPid != 0)
    {
        PauseResumeThreadList(SppSvcPid, TRUE);
        OutputDebugStringEx(L"[SppExtComObjPatcher] Process sppsvc.exe [pid: %u] resumed.\n", SppSvcPid);
    }

    WaitForSingleObject(pi.hProcess, INFINITE);
    GetExitCodeProcess(pi.hProcess, &dwRet);
    OutputDebugStringEx(L"[SppExtComObjPatcher] Process %s [pid: %u] exited with code %u.\n", lpCmdLine, pi.dwProcessId, dwRet);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    ExitProcess(dwRet);
}
