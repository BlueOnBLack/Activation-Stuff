#!/bin/bash
if [ -e SECOPatcher-mingw.tar.xz ];then rm SECOPatcher-mingw.tar.xz; fi
if [ -e SECOPatcher-mingw.7z ];then rm SECOPatcher-mingw.7z; fi

find_files() {
    find  \
        -path ./build_*/*.dll \
        -o -path './ldscripts/*'  \
        -o -path './SECO*/*' -not -path '*build*' -not -path '*idea*'  \
        -o -iname CMakeLists.txt  \
        -o -iname build.sh  \
        -o -iname package.sh  | cut -c 3-
}
find_files | tar -cJf SECOPatcher-mingw.tar.xz -T-
find_files  |  tr '\n' ' ' | xargs 7z a -mx9 -myx9 SECOPatcher-mingw.7z 