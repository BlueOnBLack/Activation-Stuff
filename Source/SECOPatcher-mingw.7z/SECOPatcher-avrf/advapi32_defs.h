//
// Created by Administrator on 2019/4/6.
//
#pragma once

#ifndef AVRF_ADVAPI32_DEFS_H
#define AVRF_ADVAPI32_DEFS_H

#include "pch.h"

typedef WINBOOL (WINAPI *pCryptDestroyKey)
    (HCRYPTKEY hKey);

typedef WINBOOL (WINAPI *pCryptSetKeyParam)
    (HCRYPTKEY hKey, DWORD dwParam, CONST BYTE *pbData, DWORD dwFlags);

typedef WINBOOL (WINAPI *pCryptSetHashParam)
    (HCRYPTHASH hHash, DWORD dwParam, CONST BYTE *pbData, DWORD dwFlags);

typedef WINBOOL (WINAPI *pCryptGetHashParam)
    (HCRYPTHASH hHash, DWORD dwParam, BYTE *pbData, DWORD *pdwDataLen, DWORD dwFlags);

typedef WINBOOL (WINAPI *pCryptImportKey)
    (HCRYPTPROV hProv, CONST BYTE *pbData, DWORD dwDataLen, HCRYPTKEY hPubKey, DWORD dwFlags, HCRYPTKEY *phKey);

typedef WINBOOL (WINAPI *pCryptEncrypt)
    (HCRYPTKEY hKey, HCRYPTHASH hHash, WINBOOL Final, DWORD dwFlags, BYTE *pbData, DWORD *pdwDataLen, DWORD dwBufLen);

typedef WINBOOL (WINAPI *pCryptDecrypt)
    (HCRYPTKEY hKey, HCRYPTHASH hHash, WINBOOL Final, DWORD dwFlags, BYTE *pbData, DWORD *pdwDataLen);

typedef WINBOOL (WINAPI *pCryptCreateHash)
    (HCRYPTPROV hProv, ALG_ID Algid, HCRYPTKEY hKey, DWORD dwFlags, HCRYPTHASH *phHash);

typedef WINBOOL (WINAPI *pCryptHashData)
    (HCRYPTHASH hHash, CONST BYTE *pbData, DWORD dwDataLen, DWORD dwFlags);

typedef WINBOOL (WINAPI *pCryptDestroyHash)
    (HCRYPTHASH hHash);

typedef WINBOOL (WINAPI *pCryptAcquireContextW)
    (HCRYPTPROV *phProv, LPCWSTR szContainer, LPCWSTR szProvider, DWORD dwProvType, DWORD dwFlags);

typedef WINBOOL (WINAPI *pCryptCreateHash)
    (HCRYPTPROV hProv, ALG_ID Algid, HCRYPTKEY hKey, DWORD dwFlags, HCRYPTHASH *phHash);

typedef WINBOOL (WINAPI *pCryptDestroyKey)
    (HCRYPTKEY hKey);

typedef WINBOOL (WINAPI *pCryptGetHashParam)
    (HCRYPTHASH hHash, DWORD dwParam, BYTE *pbData, DWORD *pdwDataLen, DWORD dwFlags);

typedef WINBOOL (WINAPI *pCryptHashData)
    (HCRYPTHASH hHash, CONST BYTE *pbData, DWORD dwDataLen, DWORD dwFlags);

typedef WINBOOL (WINAPI *pCryptImportKey)
    (HCRYPTPROV hProv, CONST BYTE *pbData, DWORD dwDataLen, HCRYPTKEY hPubKey, DWORD dwFlags, HCRYPTKEY *phKey);

typedef WINBOOL (WINAPI *pCryptSetHashParam)
    (HCRYPTHASH hHash, DWORD dwParam, CONST BYTE *pbData, DWORD dwFlags);

typedef WINBOOL (WINAPI *pCryptReleaseContext)
    (HCRYPTPROV hProv, DWORD dwFlags);

typedef WINBOOL (WINAPI *pCryptGenRandom)
    (HCRYPTPROV hProv, DWORD dwLen, BYTE *pbBuffer);

#define index_suffix(name) name ## _Index

enum _AdvApi_Index {
  index_suffix(CryptAcquireContextW) = 0,
  index_suffix(CryptCreateHash),
  index_suffix(CryptDecrypt),
  index_suffix(CryptDestroyHash),
  index_suffix(CryptDestroyKey),
  index_suffix(CryptEncrypt),
  index_suffix(CryptGenRandom),
  index_suffix(CryptGetHashParam),
  index_suffix(CryptHashData),
  index_suffix(CryptImportKey),
  index_suffix(CryptReleaseContext),
  index_suffix(CryptSetHashParam),
  index_suffix(CryptSetKeyParam),
  _AdvApi_Size
};

#undef index_suffix

void * AdvApiGetFunc(unsigned index, char * name);
#define LAZY_FN_ADVAPI32(funcName) ((p ## funcName) (AdvApiGetFunc(funcName ## _Index, #funcName)))

#ifdef __cplusplus
extern "C"
#endif
#endif //AVRF_ADVAPI32_DEFS_H
