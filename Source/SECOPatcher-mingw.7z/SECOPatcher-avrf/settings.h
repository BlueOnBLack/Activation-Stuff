#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct KMSServerSettings
{
  ULONG64 hwid;
  USHORT activation_interval;
  USHORT renewal_interval;
  BOOL enabled;
} KMSServerSettings;

extern KMSServerSettings g_settings;

NTSTATUS settings_update();

NTSTATUS settings_get_kmspid_for_kmspid(PWSTR kmsPid, const GUID *kmsId);

#define CLAMP(val, low, high) (val < low ? low : (val > high ? high : val))

#ifdef __cplusplus
};
#endif